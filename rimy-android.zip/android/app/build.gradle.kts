plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Build number: GitHub Actions-e github.run_number theke ashe (-PversionCode=...). Local-e 1.
val buildNum = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "com.mdy.rimy"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mdy.rimy"
        minSdk = 24
        targetSdk = 34
        versionCode = buildNum
        versionName = "1.$buildNum"
    }

    // Sob build ekই key diye sign hobe, jate auto-update install hoy
    signingConfigs {
        create("rimy") {
            storeFile = file("rimy.keystore")
            storePassword = "rimy-pass-123"
            keyAlias = "rimy"
            keyPassword = "rimy-pass-123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("rimy")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("rimy")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Offline "Hey Rimy" wake word (Vosk)
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    // FileProvider (update APK share korar jonno)
    implementation("androidx.core:core:1.13.1")
}
