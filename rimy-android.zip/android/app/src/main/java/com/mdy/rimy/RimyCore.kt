package com.mdy.rimy

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Activity ar background service duitai-i byabohar kore: phone action, TTS, mic-in.
 * evaluate: JS chalanor function (activity-r WebView ba hidden WebView).
 * launchable: activity khola jabe kina. Na hole notification diye user-ke tap korte bolbe.
 */
class RimyCore(
    private val ctx: Context,
    private val evaluate: (String) -> Unit,
    private val launchable: () -> Boolean,
    private val micRequest: (() -> Unit)?,
    private val onIdle: (() -> Unit)?
) {
    companion object {
        val VOICE_LANGS = listOf("bn", "en", "hi", "ar", "ur")
        const val CH_ALERT = "rimy_alert"
    }

    private val ui = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsQueue: (() -> Unit)? = null
    private var lastErr = ""
    private var pendingLang = "bn-BD"
    private var pendingAuto = false
    private var pendingListen = false

    private fun js(code: String) {
        ui.post { evaluate(code) }
    }

    fun destroy() {
        try { recognizer?.destroy() } catch (e: Exception) { }
        try { tts?.shutdown() } catch (e: Exception) { }
    }

    /** Kaj sheshe mic abar background wake-e fiTiye dey */
    fun idle() {
        onIdle?.invoke()
    }

    fun readScreen(): String = ScreenService.readText()

    // ---------- Phone action ----------

    /** Web theke JSON action: {"do":"call"|"sms"|"open"|"url"|"alarm"|"timer", ...} */
    fun doAction(json: String): String {
        return try {
            val o = JSONObject(json)
            lastErr = ""
            val ok = when (o.optString("do")) {
                "call" -> dial(o.optString("to"))
                "sms" -> sms(o.optString("to"), o.optString("text"))
                "open" -> openApp(o.optString("app"))
                "url" -> openUrl(o.optString("url"))
                "alarm" -> alarm(o.optInt("hour", 7), o.optInt("minute", 0), o.optString("label"))
                "timer" -> timer(o.optInt("seconds", 60), o.optString("label"))
                "nav" -> nav(o.optString("action"))
                else -> false
            }
            if (ok) "ok" else "fail:" + (if (lastErr.isEmpty()) "app-na-paoa-ba-tathya-bhul" else lastErr)
        } catch (e: Exception) {
            "error:" + e.javaClass.simpleName
        }
    }

    private fun start(i: Intent, label: String): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            if (launchable()) {
                ctx.startActivity(i)
            } else {
                // Background-e activity khola jay na (Android-er niyom), tai notification-e tap korte bolbo
                notifyTap(i, label)
            }
            true
        } catch (e: Exception) {
            lastErr = e.javaClass.simpleName
            false
        }
    }

    private fun notifyTap(i: Intent, label: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pi = PendingIntent.getActivity(
            ctx, label.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Rimy dakchhe", NotificationManager.IMPORTANCE_HIGH))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH_ALERT) else Notification.Builder(ctx)
        val n = b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("R.I.M.Y: $label")
            .setContentText("Ekhane tap korle kaj-ti hobe")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(label.hashCode(), n)
    }

    // Back / home / recents: Accessibility service dorkar
    private fun nav(action: String): Boolean {
        if (!ScreenService.enabled()) {
            lastErr = "screen-access-nei (Settings > Accessibility > R.I.M.Y on koro)"
            return false
        }
        if (!ScreenService.perform(action)) {
            lastErr = "ei-kaj-holo-na"
            return false
        }
        return true
    }

    private fun digits(s: String): String = s.filter { it.isDigit() || it == '+' }

    // Call: dialer khole, user nijei call chapbe (confirm)
    private fun dial(to: String): Boolean {
        val n = digits(to)
        if (n.length < 4) {
            lastErr = "number-nei-ba-bhul"
            return false
        }
        return start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")), "call")
    }

    private fun sms(to: String, text: String): Boolean {
        val n = digits(to)
        if (n.isEmpty()) {
            lastErr = "number-nei-ba-bhul"
            return false
        }
        return start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", text), "sms")
    }

    private fun openUrl(u: String): Boolean {
        if (!u.startsWith("http")) return false
        return start(Intent(Intent.ACTION_VIEW, Uri.parse(u)), "link")
    }

    private fun openApp(name: String): Boolean {
        val q = name.trim().lowercase()
        if (q.isEmpty()) return false
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
        if (hit == null) {
            lastErr = "app-paoa-jay-ni"
            return false
        }
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
        if (launch == null) {
            lastErr = "app-khola-jay-ni"
            return false
        }
        return start(launch, name.trim())
    }

    private fun alarm(h: Int, m: Int, label: String): Boolean {
        return start(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label),
            "alarm"
        )
    }

    private fun timer(sec: Int, label: String): Boolean {
        return start(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label),
            "timer"
        )
    }

    // ---------- Native voice-out ----------

    private val ttsProgress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { jsDone() }
        override fun onError(utteranceId: String?) { jsDone() }
        override fun onError(utteranceId: String?, errorCode: Int) { jsDone() }
    }

    private fun jsDone() {
        js("window.onNativeTtsDone && window.onNativeTtsDone()")
    }

    fun warmTts() {
        withTts { }
    }

    private fun withTts(action: (TextToSpeech) -> Unit) {
        val engine = tts
        if (engine != null && ttsReady) {
            action(engine)
            return
        }
        ttsQueue = { tts?.let { action(it) } }
        if (engine == null) {
            tts = TextToSpeech(ctx) { status ->
                ttsReady = status == TextToSpeech.SUCCESS
                val q = ttsQueue
                ttsQueue = null
                if (ttsReady) {
                    tts?.setOnUtteranceProgressListener(ttsProgress)
                    q?.invoke()
                } else {
                    tts?.shutdown()
                    tts = null
                    jsDone()
                }
            }
        }
    }

    fun speak(text: String, lang: String, voiceName: String) {
        ui.post { doSpeak(text, lang, voiceName) }
    }

    fun stopSpeak() {
        ui.post { tts?.stop() }
    }

    private fun doSpeak(text: String, lang: String, voiceName: String) {
        if (text.isBlank()) {
            jsDone()
            return
        }
        withTts { engine ->
            val loc = Locale.forLanguageTag(lang)
            var res = engine.setLanguage(loc)
            if ((res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) && loc.language == "bn") {
                res = engine.setLanguage(Locale("bn", "IN"))
            }
            val pool = (engine.voices ?: emptySet()).filter {
                it.locale.language == loc.language && !it.isNetworkConnectionRequired
            }
            val chosen = (if (voiceName.isNotEmpty()) pool.firstOrNull { it.name == voiceName } else null)
                ?: pool.firstOrNull { it.name.contains("female", true) }
                ?: pool.firstOrNull { !it.name.contains("male", true) }
            if (chosen != null) {
                engine.voice = chosen
            } else if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                val msg = "Phone-e " + loc.language + " voice nei. Phone-er Text-to-speech settings-e giye ei bhasha-r voice data install koro, tahole Rimy thik bhabe bolbe."
                js("window.onNativeTtsErr && window.onNativeTtsErr(" + JSONObject.quote(msg) + ")")
                engine.setLanguage(Locale.US)
            }
            engine.setPitch(1.3f)
            engine.setSpeechRate(1.0f)
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rimy" + System.currentTimeMillis())
        }
    }

    /** Phone-e thaka voice-er list (JSON) */
    fun voices(): String {
        val engine = tts
        if (engine == null || !ttsReady) return "[]"
        val arr = JSONArray()
        for (v in engine.voices ?: emptySet()) {
            if (v.isNetworkConnectionRequired) continue
            if (v.locale.language !in VOICE_LANGS) continue
            val o = JSONObject()
            o.put("name", v.name)
            o.put("lang", v.locale.toLanguageTag())
            arr.put(o)
        }
        return arr.toString()
    }

    // ---------- Native voice-in ----------

    fun listen(lang: String, auto: Boolean) {
        ui.post { startListen(lang, auto) }
    }

    fun stopListen() {
        ui.post { recognizer?.stopListening() }
    }

    private fun startListen(lang: String, auto: Boolean) {
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang
            pendingAuto = auto
            pendingListen = true
            val req = micRequest
            if (req != null) {
                req()
            } else {
                js("window.onNativeErr && window.onNativeErr(9)")
                say("")
            }
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            js("window.onNativeErr && window.onNativeErr(5)")
            say("")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                say(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
            }
            override fun onError(error: Int) {
                js("window.onNativeErr && window.onNativeErr($error)")
                say("")
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
        if (auto) {
            intent.putExtra("android.speech.extra.ENABLE_LANGUAGE_DETECTION", true)
            intent.putStringArrayListExtra(
                "android.speech.extra.LANGUAGE_DETECTION_ALLOWED_LANGUAGES",
                arrayListOf("bn-BD", "en-US", "hi-IN", "ar-SA", "ur-PK")
            )
        }
        r.startListening(intent)
    }

    /** Mic permission-er uttor (Activity theke) */
    fun onMicResult(granted: Boolean) {
        if (granted && pendingListen) {
            startListen(pendingLang, pendingAuto)
        } else {
            js("window.onNativeErr && window.onNativeErr(9)")
            say("")
        }
        pendingListen = false
    }

    private fun say(text: String) {
        js("window.onNativeSpeech && window.onNativeSpeech(" + JSONObject.quote(text) + ")")
    }
}
