package com.mdy.rimy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * GitHub-er latest Release check kore. Notun version thakle APK download kore,
 * notification-e dekhay; tap korle Android-er install screen khule.
 */
object UpdateChecker {
    private const val API = "https://api.github.com/repos/mdy369897/R.I.M.Y/releases/latest"
    private const val CH = "rimy_update"
    private const val NOTE_ID = 11

    class Found(val code: Int, val url: String, val tag: String)

    fun latest(): Found? {
        val conn = URL(API).openConnection() as HttpURLConnection
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        try {
            if (conn.responseCode != 200) return null
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val tag = j.optString("tag_name")
            val code = tag.removePrefix("v").toIntOrNull() ?: return null
            val assets = j.optJSONArray("assets") ?: return null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) {
                    return Found(code, a.optString("browser_download_url"), tag)
                }
            }
            return null
        } finally {
            conn.disconnect()
        }
    }

    fun download(ctx: Context, url: String): File {
        val f = File(ctx.cacheDir, "rimy-update.apk")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        try {
            conn.inputStream.use { input ->
                FileOutputStream(f).use { out -> input.copyTo(out) }
            }
        } finally {
            conn.disconnect()
        }
        return f
    }

    fun notifyReady(ctx: Context, apk: File, tag: String) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", apk)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            ctx, NOTE_ID, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "App update", NotificationManager.IMPORTANCE_DEFAULT))
            b = Notification.Builder(ctx, CH)
        } else {
            b = Notification.Builder(ctx)
        }
        val n = b.setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("R.I.M.Y notun version ($tag) ready")
            .setContentText("Tap kore install koro")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTE_ID, n)
    }
}
