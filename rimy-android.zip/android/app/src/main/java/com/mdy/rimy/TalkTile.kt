package com.mdy.rimy

import android.content.Intent
import android.os.Build
import android.service.quicksettings.TileService

/** Quick Settings tile: ek tap-e R.I.M.Y ekbar shunbe */
class TalkTile : TileService() {
    override fun onClick() {
        val i = Intent(this, WakeService::class.java).setAction(WakeService.ACTION_TALK)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
}
