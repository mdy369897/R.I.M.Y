package com.mdy.rimy

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Screen-er lekha porar jonno Accessibility Service.
 * User Settings > Accessibility theke nijei on korbe. Password field kokhono porbe na.
 */
class ScreenService : AccessibilityService() {

    companion object {
        @Volatile var instance: ScreenService? = null

        /** "NOT_ENABLED" = service on nai; "EMPTY" = kono lekha nei; na hole screen-er lekha */
        fun readText(): String {
            val s = instance ?: return "NOT_ENABLED"
            val t = s.dump()
            return if (t.isBlank()) "EMPTY" else t
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Amra event dhori na, shudhu active window-er lekha dorkar hole porhi
    }

    override fun onInterrupt() {}

    private fun dump(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        walk(root, sb, 0)
        return sb.toString().take(4000)
    }

    private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (n == null || depth > 40 || sb.length > 4000) return
        if (!n.isPassword) {
            val t = n.text?.toString()?.trim().orEmpty().ifEmpty {
                n.contentDescription?.toString()?.trim().orEmpty()
            }
            if (t.isNotEmpty()) sb.append(t).append('\n')
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), sb, depth + 1)
    }
}
