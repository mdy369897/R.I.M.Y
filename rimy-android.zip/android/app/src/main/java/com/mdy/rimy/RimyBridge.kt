package com.mdy.rimy

import android.webkit.JavascriptInterface

/** Web page-er "RimyNative" object. Activity ar hidden WebView duitai ei-i byabohar kore. */
class RimyBridge(
    private val core: RimyCore,
    private val onSetWake: (Boolean) -> Unit,
    private val onOpenAccess: () -> Unit,
    private val onSaveImage: (String) -> String,
    private val onOpenCamera: () -> Unit
) {
    @JavascriptInterface
    fun doAction(json: String): String = core.doAction(json)

    @JavascriptInterface
    fun listen(lang: String, auto: Boolean) = core.listen(lang, auto)

    @JavascriptInterface
    fun stopListen() = core.stopListen()

    @JavascriptInterface
    fun speak(text: String, lang: String, voiceName: String) = core.speak(text, lang, voiceName)

    @JavascriptInterface
    fun stopSpeak() = core.stopSpeak()

    @JavascriptInterface
    fun voices(): String = core.voices()

    @JavascriptInterface
    fun readScreen(): String = core.readScreen()

    @JavascriptInterface
    fun setWake(on: Boolean) = onSetWake(on)

    @JavascriptInterface
    fun openAccess() = onOpenAccess()

    /** Kaj sheshe background wake abar shuru */
    @JavascriptInterface
    fun wakeIdle() = core.idle()

    /** Chhobi Downloads folder-e save kore. Return "ok" ba "ERR" */
    @JavascriptInterface
    fun saveImage(dataUrl: String): String = onSaveImage(dataUrl)

    /** Phone-er camera app khule */
    @JavascriptInterface
    fun openCamera() = onOpenCamera()
}
