package com.mdy.rimy

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    companion object {
        const val PAGE = "https://mdy369897.github.io/R.I.M.Y/"
        const val REQ_MIC = 101
        const val REQ_WAKE = 103
        const val REQ_FILE = 202
    }

    private lateinit var web: WebView
    private lateinit var core: RimyCore
    private var pendingWake = false

    // Gallery theke chhobi nite (WebView-er file chooser)
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        core = RimyCore(
            this,
            { code -> web.evaluateJavascript(code, null) },
            { true },
            { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC) },
            null
        )
        core.warmTts()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(
            RimyBridge(core, { on -> toggleWake(on) }, { openAccessSettings() }),
            "RimyNative"
        )
        pendingWake = intent?.getBooleanExtra("wake", false) == true
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (pendingWake) {
                    pendingWake = false
                    web.evaluateJavascript("window.onWake && window.onWake()", null)
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                val intent = try {
                    fileChooserParams?.createIntent()
                } catch (e: Exception) {
                    null
                }
                if (intent == null) {
                    fileCallback = null
                    return false
                }
                return try {
                    startActivityForResult(intent, REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }

            override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                if (request.resources.contains(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                    request.grant(arrayOf(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                } else {
                    request.deny()
                }
            }
        }
        web.loadUrl(PAGE)
        checkUpdate()
    }

    // Notun APK ache kina dekhe, thakle download kore notification dey
    private fun checkUpdate() {
        Thread {
            try {
                val found = UpdateChecker.latest() ?: return@Thread
                val installed = packageManager.getPackageInfo(packageName, 0).versionCode
                if (found.code <= installed) return@Thread
                val apk = UpdateChecker.download(this, found.url)
                UpdateChecker.notifyReady(this, apk, found.tag)
            } catch (e: Exception) {
            }
        }.start()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("wake", false) == true) {
            web.evaluateJavascript("window.onWake && window.onWake()", null)
        }
    }

    override fun onResume() {
        super.onResume()
        WakeService.appVisible = true
        // App khule "dakchhe" notification sore jabe
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(8)
        // Background-e wake hoye kaj hoye thakle page abar load kori, jate notun message dekhay
        if (WakeService.dirty) {
            WakeService.dirty = false
            web.reload()
        }
        // App khola thakle background shunar pause (mic ekbar-i byabohar hobe)
        if (WakeService.isRunning) {
            startService(Intent(this, WakeService::class.java).setAction(WakeService.ACTION_PAUSE))
        }
    }

    override fun onPause() {
        super.onPause()
        WakeService.appVisible = false
        if (WakeService.isRunning) {
            startService(Intent(this, WakeService::class.java).setAction(WakeService.ACTION_RESUME))
        }
    }

    override fun onDestroy() {
        core.destroy()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun openAccessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
        }
    }

    // "Hey Rimy" background service chalu/bondho
    private fun toggleWake(on: Boolean) {
        val svc = Intent(this, WakeService::class.java)
        if (!on) {
            startService(svc.setAction(WakeService.ACTION_STOP))
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), REQ_WAKE)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_WAKE + 1)
        }
        try {
            startForegroundService(svc.setAction(WakeService.ACTION_START))
        } catch (e: Exception) {
            web.evaluateJavascript("window.onNativeErr && window.onNativeErr(9)", null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQ_MIC -> {
                val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
                core.onMicResult(ok)
            }
            REQ_WAKE -> {
                val idx = permissions.indexOf(Manifest.permission.RECORD_AUDIO)
                if (idx >= 0 && grantResults.getOrNull(idx) == PackageManager.PERMISSION_GRANTED) {
                    toggleWake(true)
                } else {
                    web.evaluateJavascript("window.onNativeErr && window.onNativeErr(9)", null)
                }
            }
            REQ_WAKE + 1 -> { }
        }
    }
}
