package com.mdy.rimy

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : Activity() {

    companion object {
        const val PAGE = "https://mdy369897.github.io/R.I.M.Y/"
        const val REQ_MIC = 101
        const val REQ_WAKE = 103
        const val REQ_FILE = 202
        const val REQ_CAM = 301
    }

    private lateinit var web: WebView
    private lateinit var core: RimyCore
    private var pendingWake = false

    // Gallery theke chhobi nite (WebView-er file chooser)
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var camFile: File? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        core = RimyCore(
            this,
            { code -> web.evaluateJavascript(code, null) },
            { true },
            { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC) },
            null
        )
        core.warmTts()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(
            RimyBridge(core, { on -> toggleWake(on) }, { openAccessSettings() }, { url -> saveChhobi(url) }, { openCamera() }, { runOnUiThread { openMapsApp() } }),
            "RimyNative"
        )
        pendingWake = intent?.getBooleanExtra("wake", false) == true
        web.webViewClient = object : WebViewClient() {
            // Bahire-r link (jemon Google Maps) WebView-e na khule phone-er app/browser-e khule
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val s = request?.url?.toString() ?: return false
                if (s.startsWith(PAGE) || s.startsWith("file:") || s.startsWith("data:") || s.startsWith("blob:") || s.startsWith("about:")) return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s)).addCategory(Intent.CATEGORY_BROWSABLE))
                    true
                } catch (e: Exception) {
                    false
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (pendingWake) {
                    pendingWake = false
                    web.evaluateJavascript("window.onWake && window.onWake()", null)
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                val intent = try {
                    fileChooserParams?.createIntent()
                } catch (e: Exception) {
                    null
                }
                if (intent == null) {
                    fileCallback = null
                    return false
                }
                return try {
                    startActivityForResult(intent, REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }

            override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                if (request.resources.contains(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                    request.grant(arrayOf(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                } else {
                    request.deny()
                }
            }
        }
        RimyCore.uiHandler = { n -> runOnUiThread { web.evaluateJavascript("window.rimyUi && window.rimyUi('" + n + "')", null) }; true }
        web.loadUrl(PAGE)
        checkUpdate()
    }

    // Google Maps app ache to sei-ta, na thakle browser-e https link
    private fun openMapsApp() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).setPackage("com.google.android.apps.maps"))
            return
        } catch (e: Exception) {
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps")).addCategory(Intent.CATEGORY_BROWSABLE))
        } catch (e: Exception) {
        }
    }

    // Notun APK ache kina dekhe, thakle download kore notification dey
    private fun checkUpdate() {
        Thread {
            try {
                val found = UpdateChecker.latest() ?: return@Thread
                val installed = packageManager.getPackageInfo(packageName, 0).versionCode
                if (found.code <= installed) return@Thread
                val apk = UpdateChecker.download(this, found.url)
                UpdateChecker.notifyReady(this, apk, found.tag)
            } catch (e: Exception) {
            }
        }.start()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("wake", false) == true) {
            web.evaluateJavascript("window.onWake && window.onWake()", null)
        }
    }

    override fun onResume() {
        super.onResume()
        WakeService.appVisible = true
        // App khule "dakchhe" notification sore jabe
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(8)
        // Background-e wake hoye kaj hoye thakle page abar load kori, jate notun message dekhay
        if (WakeService.dirty) {
            WakeService.dirty = false
            web.reload()
        }
        // App khola thakle background shunar pause (mic ekbar-i byabohar hobe)
        if (WakeService.isRunning) {
            startService(Intent(this, WakeService::class.java).setAction(WakeService.ACTION_PAUSE))
        }
    }

    override fun onPause() {
        super.onPause()
        WakeService.appVisible = false
        if (WakeService.isRunning) {
            startService(Intent(this, WakeService::class.java).setAction(WakeService.ACTION_RESUME))
        }
    }

    override fun onDestroy() {
        core.destroy()
        RimyCore.uiHandler = null
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    /** Phone-er camera khule chhobi nei (JS: RimyNative.openCamera) */
    private fun openCamera() {
        runOnUiThread {
            try {
                val f = File(cacheDir, "rimy_cam.jpg")
                camFile = f
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    .putExtra(MediaStore.EXTRA_OUTPUT, uri)
                    .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivityForResult(i, REQ_CAM)
            } catch (e: Exception) {
                camFile = null
                web.evaluateJavascript("window.onNativePhoto && window.onNativePhoto('')", null)
            }
        }
    }

    private fun handleCamResult(resultCode: Int) {
        val f = camFile
        camFile = null
        val url = if (resultCode == RESULT_OK && f != null && f.exists()) photoDataUrl(f) else null
        web.evaluateJavascript("window.onNativePhoto && window.onNativePhoto('" + (url ?: "") + "')", null)
    }

    /** Chhobi-ta chhoto kore JPEG data URL banay (camera-r rotation thik kore) */
    private fun photoDataUrl(f: File): String? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, o)
            var sample = 1
            while (maxOf(o.outWidth, o.outHeight) / sample > 2048) sample *= 2
            var bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
            val big = maxOf(bmp.width, bmp.height)
            if (big > 1024) {
                val s = 1024f / big
                bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            }
            val rot = try {
                when (ExifInterface(f.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } catch (e: Exception) {
                0f
            }
            if (rot != 0f) {
                val m = Matrix().apply { postRotate(rot) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
            "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    /** Chhobi Downloads folder-e save kore. Return "ok" ba "ERR" */
    private fun saveChhobi(dataUrl: String): String {
        return try {
            val comma = dataUrl.indexOf(',')
            if (comma < 0) return "ERR"
            val mime = dataUrl.substring(5, comma).substringBefore(';')
            val ext = if (mime.contains("png")) "png" else "jpg"
            val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
            val name = "rimy-chhobi-" + System.currentTimeMillis() + "." + ext
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return "ERR"
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return "ERR"
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                File(dir, name).writeBytes(bytes)
            }
            "ok"
        } catch (e: Exception) {
            "ERR"
        }
    }

    private fun openAccessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
        }
    }

    // "Hey Rimy" background service chalu/bondho
    private fun toggleWake(on: Boolean) {
        val svc = Intent(this, WakeService::class.java)
        if (!on) {
            startService(svc.setAction(WakeService.ACTION_STOP))
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), REQ_WAKE)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_WAKE + 1)
        }
        try {
            startForegroundService(svc.setAction(WakeService.ACTION_START))
        } catch (e: Exception) {
            web.evaluateJavascript("window.onNativeErr && window.onNativeErr(9)", null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAM) {
            handleCamResult(resultCode)
            return
        }
        if (requestCode == REQ_FILE) {
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQ_MIC -> {
                val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
                core.onMicResult(ok)
            }
            REQ_WAKE -> {
                val idx = permissions.indexOf(Manifest.permission.RECORD_AUDIO)
                if (idx >= 0 && grantResults.getOrNull(idx) == PackageManager.PERMISSION_GRANTED) {
                    toggleWake(true)
                } else {
                    web.evaluateJavascript("window.onNativeErr && window.onNativeErr(9)", null)
                }
            }
            REQ_WAKE + 1 -> { }
        }
    }
}
