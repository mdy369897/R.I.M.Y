package com.mdy.rimy

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {

    companion object {
        const val PAGE = "https://mdy369897.github.io/R.I.M.Y/"
        const val REQ_MIC = 101
    }

    private lateinit var web: WebView
    private var recognizer: SpeechRecognizer? = null
    private var pendingLang = "bn-BD"
    private var pendingAuto = false
    private var pendingListen = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "RimyNative")
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                // Shudhu mic-er onumoti-i dey
                if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                    request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                } else {
                    request.deny()
                }
            }
        }
        web.loadUrl(PAGE)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    inner class Bridge {

        /** Web theke JSON action: {"do":"call"|"sms"|"open"|"url"|"alarm"|"timer", ...} */
        @JavascriptInterface
        fun doAction(json: String): String {
            return try {
                val o = JSONObject(json)
                val ok = when (o.optString("do")) {
                    "call" -> dial(o.optString("to"))
                    "sms" -> sms(o.optString("to"), o.optString("text"))
                    "open" -> openApp(o.optString("app"))
                    "url" -> openUrl(o.optString("url"))
                    "alarm" -> alarm(o.optInt("hour", 7), o.optInt("minute", 0), o.optString("label"))
                    "timer" -> timer(o.optInt("seconds", 60), o.optString("label"))
                    else -> false
                }
                if (ok) "ok" else "fail"
            } catch (e: Exception) {
                "error"
            }
        }

        @JavascriptInterface
        fun listen(lang: String, auto: Boolean) {
            runOnUiThread { startListen(lang, auto) }
        }

        @JavascriptInterface
        fun stopListen() {
            runOnUiThread { recognizer?.stopListening() }
        }
    }

    private fun start(i: Intent): Boolean {
        return try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun digits(s: String): String = s.filter { it.isDigit() || it == '+' }

    // Call: dialer khole, user nijei call chapbe (confirm)
    private fun dial(to: String): Boolean {
        val n = digits(to)
        if (n.length < 4) return false
        return start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")))
    }

    // Message: SMS app-e lekha prefilled, user nijei pathabe
    private fun sms(to: String, text: String): Boolean {
        val n = digits(to)
        if (n.isEmpty()) return false
        return start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", text))
    }

    private fun openUrl(u: String): Boolean {
        if (!u.startsWith("http")) return false
        return start(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    }

    // App name diye phone-er launcher theke khuje khola
    private fun openApp(name: String): Boolean {
        val q = name.trim().lowercase()
        if (q.isEmpty()) return false
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        return start(launch)
    }

    // Alarm: clock app-e set hoy, user confirm kore
    private fun alarm(h: Int, m: Int, label: String): Boolean {
        return start(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
        )
    }

    private fun timer(sec: Int, label: String): Boolean {
        return start(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
        )
    }

    // Native voice-in: WebView-te browser speech kaj na korle eta use hoy
    private fun startListen(lang: String, auto: Boolean) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang
            pendingAuto = auto
            pendingListen = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                say(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
            }
            override fun onError(error: Int) { say("") }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        if (auto) {
            // Auto: Android 14+ phone-e bhasha nijei chine (na thakle EXTRA_LANGUAGE-i use hoy)
            intent.putExtra("android.speech.extra.ENABLE_LANGUAGE_DETECTION", true)
            intent.putStringArrayListExtra(
                "android.speech.extra.LANGUAGE_DETECTION_ALLOWED_LANGUAGES",
                arrayListOf("bn-BD", "en-US", "hi-IN", "ar-SA", "ur-PK")
            )
        }
        r.startListening(intent)
    }

    private fun say(text: String) {
        runOnUiThread {
            web.evaluateJavascript(
                "window.onNativeSpeech && window.onNativeSpeech(" + JSONObject.quote(text) + ")",
                null
            )
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (ok && pendingListen) startListen(pendingLang, pendingAuto) else say("")
            pendingListen = false
        }
    }
}
