package com.mdy.rimy

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.ValueCallback
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        const val PAGE = "https://mdy369897.github.io/R.I.M.Y/"
        const val REQ_MIC = 101
        const val REQ_WAKE = 103
        val VOICE_LANGS = listOf("bn", "en", "hi", "ar", "ur")
    }

    private lateinit var web: WebView
    private var recognizer: SpeechRecognizer? = null
    private var pendingLang = "bn-BD"
    private var pendingAuto = false
    private var pendingListen = false

    // Hey Rimy theke khula holeo JS-ke jaanabo
    private var pendingWake = false

    // Shesh kaj-er karon (web-e dekhabo)
    private var lastErr = ""

    // Gallery theke chhobi nite (WebView-er file chooser)
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val REQ_FILE = 202

    // Native voice-out (phone-er nijer TTS)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsQueue: (() -> Unit)? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "RimyNative")
        pendingWake = intent?.getBooleanExtra("wake", false) == true
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (pendingWake) {
                    pendingWake = false
                    jsCall("window.onWake && window.onWake()")
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                val intent = try {
                    fileChooserParams?.createIntent()
                } catch (e: Exception) {
                    null
                }
                if (intent == null) {
                    fileCallback = null
                    return false
                }
                return try {
                    startActivityForResult(intent, REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                // Shudhu mic-er onumoti-i dey
                if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                    request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                } else {
                    request.deny()
                }
            }
        }
        web.loadUrl(PAGE)
        // TTS-ke agey thekei init koro, jate voice list settings-e ready thake
        withTts { }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("wake", false) == true) {
            jsCall("window.onWake && window.onWake()")
        }
    }

    override fun onResume() {
        super.onResume()
        WakeService.appVisible = true
        // App khola: background shunar pause (MainActivity-r mic-er jonno)
        if (WakeService.isRunning) {
            startService(Intent(this, WakeService::class.java).setAction(WakeService.ACTION_PAUSE))
        }
    }

    override fun onPause() {
        super.onPause()
        WakeService.appVisible = false
        if (WakeService.isRunning) {
            startService(Intent(this, WakeService::class.java).setAction(WakeService.ACTION_RESUME))
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    inner class Bridge {

        /** Web theke JSON action: {"do":"call"|"sms"|"open"|"url"|"alarm"|"timer", ...} */
        @JavascriptInterface
        fun doAction(json: String): String {
            return try {
                val o = JSONObject(json)
                lastErr = ""
                val ok = when (o.optString("do")) {
                    "call" -> dial(o.optString("to"))
                    "sms" -> sms(o.optString("to"), o.optString("text"))
                    "open" -> openApp(o.optString("app"))
                    "url" -> openUrl(o.optString("url"))
                    "alarm" -> alarm(o.optInt("hour", 7), o.optInt("minute", 0), o.optString("label"))
                    "timer" -> timer(o.optInt("seconds", 60), o.optString("label"))
                    else -> false
                }
                if (ok) "ok" else "fail:" + (if (lastErr.isEmpty()) "app-na-paoa-ba-tathya-bhul" else lastErr)
            } catch (e: Exception) {
                "error:" + e.javaClass.simpleName
            }
        }

        /** "Hey Rimy" background-e shonar on/off */
        @JavascriptInterface
        fun setWake(on: Boolean) {
            runOnUiThread { toggleWake(on) }
        }

        /** Screen-er lekha: "NOT_ENABLED" / "EMPTY" / lekha */
        @JavascriptInterface
        fun readScreen(): String = ScreenService.readText()

        /** Settings-e Accessibility page khola */
        @JavascriptInterface
        fun openAccess() {
            runOnUiThread {
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun listen(lang: String, auto: Boolean) {
            runOnUiThread { startListen(lang, auto) }
        }

        @JavascriptInterface
        fun stopListen() {
            runOnUiThread { recognizer?.stopListening() }
        }

        /** Rimy-r reply phone-er nijer voice-e bolbe. voiceName khali hole auto (meye-r moto) voice */
        @JavascriptInterface
        fun speak(text: String, lang: String, voiceName: String) {
            runOnUiThread { doSpeak(text, lang, voiceName) }
        }

        @JavascriptInterface
        fun stopSpeak() {
            runOnUiThread { tts?.stop() }
        }

        /** Phone-e thaka voice-er list (JSON): [{"name":..., "lang":...}] */
        @JavascriptInterface
        fun voices(): String {
            val engine = tts
            if (engine == null || !ttsReady) return "[]"
            val arr = JSONArray()
            for (v in engine.voices ?: emptySet()) {
                if (v.isNetworkConnectionRequired) continue
                if (v.locale.language !in VOICE_LANGS) continue
                val o = JSONObject()
                o.put("name", v.name)
                o.put("lang", v.locale.toLanguageTag())
                arr.put(o)
            }
            return arr.toString()
        }
    }

    // Hey Rimy service chalu/bondho. Mic-er onumoti na thakle age chaibe.
    private fun toggleWake(on: Boolean) {
        val svc = Intent(this, WakeService::class.java)
        if (!on) {
            startService(svc.setAction(WakeService.ACTION_STOP))
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), REQ_WAKE)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_WAKE + 1)
        }
        try {
            startForegroundService(svc.setAction(WakeService.ACTION_START))
        } catch (e: Exception) {
            jsCall("window.onNativeErr && window.onNativeErr(9)")
        }
    }

    private fun start(i: Intent): Boolean {
        return try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            lastErr = e.javaClass.simpleName
            false
        }
    }

    private fun digits(s: String): String = s.filter { it.isDigit() || it == '+' }

    // Call: dialer khole, user nijei call chapbe (confirm)
    private fun dial(to: String): Boolean {
        val n = digits(to)
        if (n.length < 4) {
            lastErr = "number-nei-ba-bhul"
            return false
        }
        return start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")))
    }

    // Message: SMS app-e lekha prefilled, user nijei pathabe
    private fun sms(to: String, text: String): Boolean {
        val n = digits(to)
        if (n.isEmpty()) {
            lastErr = "number-nei-ba-bhul"
            return false
        }
        return start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", text))
    }

    private fun openUrl(u: String): Boolean {
        if (!u.startsWith("http")) return false
        return start(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    }

    // App name diye phone-er launcher theke khuje khola
    private fun openApp(name: String): Boolean {
        val q = name.trim().lowercase()
        if (q.isEmpty()) return false
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
        if (hit == null) {
            lastErr = "app-paoa-jay-ni"
            return false
        }
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
        if (launch == null) {
            lastErr = "app-khola-jay-ni"
            return false
        }
        return start(launch)
    }

    // Alarm: clock app-e set hoy, user confirm kore
    private fun alarm(h: Int, m: Int, label: String): Boolean {
        return start(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
        )
    }

    private fun timer(sec: Int, label: String): Boolean {
        return start(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
        )
    }

    // ---------- Native voice-out ----------

    private val ttsProgress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { jsDone() }
        override fun onError(utteranceId: String?) { jsDone() }
        override fun onError(utteranceId: String?, errorCode: Int) { jsDone() }
    }

    private fun jsCall(js: String) {
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    private fun jsDone() {
        jsCall("window.onNativeTtsDone && window.onNativeTtsDone()")
    }

    // TTS engine tayer hole kaj chalao, na thakle agey init kore rakho
    private fun withTts(action: (TextToSpeech) -> Unit) {
        val engine = tts
        if (engine != null && ttsReady) {
            action(engine)
            return
        }
        ttsQueue = { tts?.let { action(it) } }
        if (engine == null) {
            tts = TextToSpeech(this) { status ->
                ttsReady = status == TextToSpeech.SUCCESS
                val q = ttsQueue
                ttsQueue = null
                if (ttsReady) {
                    tts?.setOnUtteranceProgressListener(ttsProgress)
                    q?.invoke()
                } else {
                    tts?.shutdown()
                    tts = null
                    jsDone()
                }
            }
        }
    }

    private fun doSpeak(text: String, lang: String, voiceName: String) {
        if (text.isBlank()) {
            jsDone()
            return
        }
        withTts { engine ->
            val loc = Locale.forLanguageTag(lang)
            var res = engine.setLanguage(loc)
            // Bangla-r jonno Bangladesh na paoa gele India-r Bangla-o chesta
            if ((res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) && loc.language == "bn") {
                res = engine.setLanguage(Locale("bn", "IN"))
            }
            val pool = (engine.voices ?: emptySet()).filter {
                it.locale.language == loc.language && !it.isNetworkConnectionRequired
            }
            // Age user je voice select korechhe seta; na thakle meye-r moto (female) voice
            val chosen = (if (voiceName.isNotEmpty()) pool.firstOrNull { it.name == voiceName } else null)
                ?: pool.firstOrNull { it.name.contains("female", true) }
                ?: pool.firstOrNull { !it.name.contains("male", true) }
            if (chosen != null) {
                engine.voice = chosen
            } else if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                val msg = "Phone-e " + loc.language + " voice nei. Phone-er Text-to-speech settings-e giye ei bhasha-r voice data install koro, tahole Rimy thik bhabe bolbe."
                jsCall("window.onNativeTtsErr && window.onNativeTtsErr(" + JSONObject.quote(msg) + ")")
                engine.setLanguage(Locale.US)
            }
            engine.setPitch(1.3f)
            engine.setSpeechRate(1.0f)
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rimy" + System.currentTimeMillis())
        }
    }

    // ---------- Native voice-in ----------

    // WebView-te browser speech kaj na korle eta use hoy
    private fun startListen(lang: String, auto: Boolean) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang
            pendingAuto = auto
            pendingListen = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            jsCall("window.onNativeErr && window.onNativeErr(5)")
            say("")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                say(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
            }
            override fun onError(error: Int) {
                // Error code web-e dekhabo, jate bojha jay kon somossha
                jsCall("window.onNativeErr && window.onNativeErr($error)")
                say("")
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            // Kotha thamar por ektu tara-tari uttor: 1.2 sec (age chhilo beshi)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
        if (auto) {
            // Auto: Android 14+ phone-e bhasha nijei chine (na thakle EXTRA_LANGUAGE-i use hoy)
            intent.putExtra("android.speech.extra.ENABLE_LANGUAGE_DETECTION", true)
            intent.putStringArrayListExtra(
                "android.speech.extra.LANGUAGE_DETECTION_ALLOWED_LANGUAGES",
                arrayListOf("bn-BD", "en-US", "hi-IN", "ar-SA", "ur-PK")
            )
        }
        r.startListening(intent)
    }

    private fun say(text: String) {
        jsCall("window.onNativeSpeech && window.onNativeSpeech(" + JSONObject.quote(text) + ")")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_WAKE) {
            val idx = permissions.indexOf(Manifest.permission.RECORD_AUDIO)
            if (idx >= 0 && grantResults.getOrNull(idx) == PackageManager.PERMISSION_GRANTED) {
                toggleWake(true)
            } else {
                jsCall("window.onNativeErr && window.onNativeErr(9)")
            }
            return
        }
        if (requestCode == REQ_WAKE + 1) return
        if (requestCode == REQ_MIC) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (ok && pendingListen) {
                startListen(pendingLang, pendingAuto)
            } else {
                jsCall("window.onNativeErr && window.onNativeErr(9)")
                say("")
            }
            pendingListen = false
        }
    }
}
