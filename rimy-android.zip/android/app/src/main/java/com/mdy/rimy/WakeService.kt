package com.mdy.rimy

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/**
 * Background-e "Hey Rimy" shunte service.
 * - Vosk diye offline "rimy" shonar.
 * - App background-e thakle ekta hidden WebView-te Rimy-r puro web app chole,
 *   tai news/weather/Gemini/phone action sob kaj korbe.
 * - App khola thakle service pause hoy, Activity-r WebView kaj kore.
 */
class WakeService : Service() {

    companion object {
        const val ACTION_START = "com.mdy.rimy.WAKE_START"
        const val ACTION_STOP = "com.mdy.rimy.WAKE_STOP"
        const val ACTION_PAUSE = "com.mdy.rimy.WAKE_PAUSE"
        const val ACTION_RESUME = "com.mdy.rimy.WAKE_RESUME"

        const val CH_LISTEN = "rimy_wake_min"
        const val CH_ALERT = "rimy_alert"
        const val NOTE_LISTEN = 7
        const val NOTE_ALERT = 8

        private const val MODEL_NAME = "vosk-model-small-en-us-0.15"
        private const val MODEL_URL = "https://alphacephei.com/vosk/models/$MODEL_NAME.zip"
        private const val SAMPLE_RATE = 16000.0f

        private const val GRAMMAR = "[\"hey\", \"rimy\", \"rimi\", \"remy\", \"[unk]\"]"
        private val WORDS = listOf("rimy", "rimi", "remy")
        private const val CMD_GRAMMAR =
            "[\"back\", \"home\", \"recent\", \"recents\", \"notification\", \"notifications\", \"youtube\", \"whatsapp\", \"jao\", \"go\", \"[unk]\"]"

        @Volatile var isRunning = false
        @Volatile var appVisible = false
        // Background-e kaj hoyeche, app khule Activity page abar load korbe
        @Volatile var dirty = false

        fun heardWake(text: String): Boolean {
            val t = text.lowercase()
            return WORDS.any { t.contains(it) }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var model: Model? = null
    private var speech: SpeechService? = null
    private var paused = false
    private var lastWake = 0L
    private var hidden: WebView? = null
    private var hiddenReady = false
    private var wakeQueued = false
    @Volatile private var commanding = false
    private val restart = Runnable { startListening() }

    // Hidden WebView-er JS ke kaj dey; mic-er kaj-o ekhan theke hoy
    private val core: RimyCore = RimyCore(
        this,
        { code ->
            if (code.contains("onNativeErr")) diagMic(code)
            if (code.contains("onNativeSpeech")) diagHeard(code)
            hidden?.evaluateJavascript(code, null)
        },
        { appVisible },
        null,
        { main.postDelayed({ if (!appVisible && !paused) startListening() }, 800L) }
    )
    private val bridge: RimyBridge = RimyBridge(core, { }, { })

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                isRunning = false
                main.removeCallbacks(restart)
                stopListening()
                stopHidden()
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> {
                paused = true
                main.removeCallbacks(restart)
                stopListening()
                stopHidden()
                return START_STICKY
            }
            ACTION_RESUME -> {
                paused = false
                startHidden()
                loadModelThenStart()
                return START_STICKY
            }
        }
        // ACTION_START: foreground-e nilo (5 sec-er modhye startForeground lagbei)
        makeChannels()
        val note = listenNotification("Model prostut hocche...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTE_LISTEN, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTE_LISTEN, note)
        }
        paused = appVisible
        if (!paused) startHidden()
        loadModelThenStart()
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        main.removeCallbacks(restart)
        stopListening()
        stopHidden()
        worker.shutdownNow()
        core.destroy()
        super.onDestroy()
    }

    // ---------- Hidden WebView ----------

    @SuppressLint("SetJavaScriptEnabled")
    private fun startHidden() {
        if (hidden != null) return
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.addJavascriptInterface(bridge, "RimyNative")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                hiddenReady = true
                if (wakeQueued) {
                    wakeQueued = false
                    fireWake()
                }
            }
        }
        w.webChromeClient = WebChromeClient()
        hidden = w
        hiddenReady = false
        w.loadUrl(MainActivity.PAGE)
    }

    private fun stopHidden() {
        try {
            hidden?.stopLoading()
            hidden?.destroy()
        } catch (e: Exception) {
        }
        hidden = null
        hiddenReady = false
        wakeQueued = false
    }

    private fun fireWake() {
        dirty = true
        hidden?.evaluateJavascript("window.onWake && window.onWake()", null)
    }

    // ---------- Model: prothombar download, tarpor offline ----------

    private fun loadModelThenStart() {
        if (model != null) {
            updateNote("Hey Rimy shunchhe")
            startListening()
            return
        }
        worker.execute {
            try {
                val dir = File(filesDir, MODEL_NAME)
                if (!File(dir, "am").exists()) {
                    downloadModel(dir)
                }
                val m = Model(dir.absolutePath)
                model = m
                main.post {
                    updateNote("Hey Rimy shunchhe")
                    startListening()
                }
            } catch (e: Exception) {
                main.post { updateNote("Model pawa jay ni, internet check koro") }
            }
        }
    }

    private fun downloadModel(target: File) {
        val zip = File(cacheDir, "$MODEL_NAME.zip")
        val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.inputStream.use { input ->
            FileOutputStream(zip).use { out -> input.copyTo(out) }
        }
        conn.disconnect()

        val tmp = File(filesDir, "$MODEL_NAME.tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val out = File(tmp, entry.name)
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        zip.delete()
        val inner = tmp.listFiles()?.firstOrNull { it.isDirectory } ?: tmp
        target.deleteRecursively()
        if (!inner.renameTo(target)) throw IllegalStateException("model rename hoy ni")
        tmp.deleteRecursively()
    }

    // ---------- Wake listening ----------

    private fun startListening() {
        if (!isRunning || paused) return
        val m = model ?: return
        stopListening()
        try {
            val rec = Recognizer(m, SAMPLE_RATE, GRAMMAR)
            val s = SpeechService(rec, SAMPLE_RATE)
            s.startListening(listener)
            speech = s
        } catch (e: Exception) {
            scheduleRestart(3000L)
        }
    }

    private fun stopListening() {
        try {
            speech?.stop()
            speech?.shutdown()
        } catch (e: Exception) {
        }
        speech = null
    }

    private fun scheduleRestart(ms: Long) {
        if (!isRunning || paused) return
        main.removeCallbacks(restart)
        main.postDelayed(restart, ms)
    }

    // Vosk callback background thread-e ase, tai sob main thread-e pathai
    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            val t = jsonField(hypothesis, "partial")
            main.post { checkWake(t) }
        }

        override fun onResult(hypothesis: String?) {
            val t = jsonField(hypothesis, "text")
            main.post { checkWake(t) }
        }

        override fun onFinalResult(hypothesis: String?) {
            val t = jsonField(hypothesis, "text")
            main.post { checkWake(t) }
        }

        override fun onError(exception: Exception?) {
            main.post { scheduleRestart(2000L) }
        }

        override fun onTimeout() {
            main.post { scheduleRestart(500L) }
        }
    }

    private fun jsonField(json: String?, key: String): String {
        return try {
            JSONObject(json ?: "").optString(key, "")
        } catch (e: Exception) {
            ""
        }
    }

    private fun checkWake(text: String) {
        if (commanding) return
        if (text.isBlank() || !heardWake(text)) return
        if (appVisible || paused) return
        val now = System.currentTimeMillis()
        if (now - lastWake < 6000L) return
        lastWake = now
        wake()
    }

    private fun wake() {
        // Wake-shonar thamiye, native-e "Ji, bolo" bolbo, tarpor command-er jonno mic chalu korbo
        stopListening()
        main.removeCallbacks(restart)
        showAlert()
        core.speak("জি, বলো", "bn-BD", "")
        main.postDelayed({ startCommand() }, 1800L)
    }

    // ---------- Command shona (Vosk, offline) ----------

    private fun startCommand() {
        if (!isRunning || paused) return
        val m = model ?: return
        stopListening()
        try {
            val rec = Recognizer(m, SAMPLE_RATE, CMD_GRAMMAR)
            val s = SpeechService(rec, SAMPLE_RATE)
            s.startListening(commandListener)
            speech = s
            commanding = true
            main.removeCallbacks(cmdTimeout)
            main.postDelayed(cmdTimeout, 6000L)
        } catch (e: Exception) {
            commanding = false
            scheduleRestart(1500L)
        }
    }

    private val cmdTimeout = Runnable { endCommand("") }

    private val commandListener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {}

        override fun onResult(hypothesis: String?) {
            val t = jsonField(hypothesis, "text")
            if (t.isNotBlank()) main.post { endCommand(t) }
        }

        override fun onFinalResult(hypothesis: String?) {
            val t = jsonField(hypothesis, "text")
            if (t.isNotBlank()) main.post { endCommand(t) }
        }

        override fun onError(exception: Exception?) {
            main.post { endCommand("") }
        }

        override fun onTimeout() {}
    }

    private fun endCommand(text: String) {
        if (!commanding) return
        commanding = false
        main.removeCallbacks(cmdTimeout)
        stopListening()
        val cmd = text.lowercase().trim()
        if (cmd.isEmpty()) {
            core.speak("কিছু শুনি নি, আবার বলো", "bn-BD", "")
        } else {
            heardNote(cmd)
            runCommand(cmd)
        }
        // Kaj sheshe abar "Hey Rimy" shunte shuru korbo
        scheduleRestart(2500L)
    }

    private fun runCommand(cmd: String) {
        val json = when {
            cmd.contains("back") -> "{\"do\":\"nav\",\"action\":\"back\"}"
            cmd.contains("home") -> "{\"do\":\"nav\",\"action\":\"home\"}"
            cmd.contains("recent") -> "{\"do\":\"nav\",\"action\":\"recents\"}"
            cmd.contains("notification") -> "{\"do\":\"nav\",\"action\":\"notifications\"}"
            cmd.contains("youtube") -> "{\"do\":\"open\",\"app\":\"YouTube\"}"
            cmd.contains("whatsapp") -> "{\"do\":\"open\",\"app\":\"WhatsApp\"}"
            else -> null
        }
        if (json == null) {
            core.speak("বুঝতে পারলাম না, আবার বলো", "bn-BD", "")
            return
        }
        val res = core.doAction(json)
        core.speak(if (res == "ok") "ঠিক আছে" else "হয়নি", "bn-BD", "")
    }

    // Ki shunlo, notification-e dekhay (debug)
    private fun heardNote(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val n = builder(CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Shuneche")
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        nm.notify(10, n)
    }

    // Rimy ki shunlo, notification-e dekhay (debug)
    private fun diagHeard(code: String) {
        val arg = code.substringAfter("window.onNativeSpeech(", "").removeSuffix(")")
        val txt = try { org.json.JSONArray("[$arg]").getString(0) } catch (e: Exception) { "" }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val n = builder(CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(if (txt.isBlank()) "Kichu shuni ni" else "Shuneche")
            .setContentText(if (txt.isBlank()) "Mic bondho hoyeche ba kotha shona jay ni" else txt)
            .setAutoCancel(true)
            .build()
        nm.notify(10, n)
    }

    // Background-e mic somossha hole notification-e kaaron dekhay (debug)
    private fun diagMic(code: String) {
        val m = Regex("onNativeErr\\((\\d+)\\)").find(code) ?: return
        val c = m.groupValues[1].toIntOrNull() ?: return
        val why = when (c) {
            2 -> "Internet lagbe"
            3 -> "Mic-e audio somossha"
            5 -> "Voice app-e somossha"
            6 -> "Kono kotha shona jay ni"
            7 -> "Kotha bujhte parlam na"
            8 -> "Voice recognizer byosto"
            9 -> "Mic permission nei"
            else -> "Recognizer error"
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val n = builder(CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Mic error (code $c)")
            .setContentText(why)
            .setAutoCancel(true)
            .build()
        nm.notify(9, n)
    }

    private fun showAlert() {
        val pi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = builder(CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("R.I.M.Y dakchhe")
            .setContentText("Ji, bolo...")
            .setContentIntent(pi)
            .setPriority(Notification.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setTimeoutAfter(8000L)
            .build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTE_ALERT, n)
    }

    // ---------- Notification ----------

    private fun updateNote(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTE_LISTEN, listenNotification(text))
    }

    private fun builder(ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)

    private fun makeChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_LISTEN, "Hey Rimy background", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Rimy dakchhe", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun listenNotification(text: String): Notification =
        builder(CH_LISTEN)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("R.I.M.Y")
            .setContentText(text)
            .setPriority(Notification.PRIORITY_MIN)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
}
