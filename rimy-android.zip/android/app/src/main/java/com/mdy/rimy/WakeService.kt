package com.mdy.rimy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * "Hey Rimy" shonar background service.
 * App khola thakle pause thake (MainActivity nijer mic byabohar kore).
 * App bondho/background-e gele SpeechRecognizer diye "rimy" shunle MainActivity khule dey.
 */
class WakeService : Service() {

    companion object {
        const val ACTION_START = "com.mdy.rimy.WAKE_START"
        const val ACTION_STOP = "com.mdy.rimy.WAKE_STOP"
        const val ACTION_PAUSE = "com.mdy.rimy.WAKE_PAUSE"
        const val ACTION_RESUME = "com.mdy.rimy.WAKE_RESUME"

        private const val CH_LISTEN = "rimy_wake"
        private const val CH_ALERT = "rimy_alert"
        private const val NOTE_LISTEN = 7
        private const val NOTE_ALERT = 8

        // Ei shobdo-gulo shunle Rimy jagbe
        private val WORDS = listOf("rimy", "rimi", "remy", "রিমি")

        @Volatile var isRunning = false
        @Volatile var appVisible = false

        fun heardWake(text: String): Boolean {
            val t = text.lowercase()
            return WORDS.any { t.contains(it) }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var paused = false
    private var lastWake = 0L
    private val restart = Runnable { startOnce() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                isRunning = false
                main.removeCallbacks(restart)
                stopRecognizer()
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> {
                paused = true
                main.removeCallbacks(restart)
                stopRecognizer()
                return START_STICKY
            }
            ACTION_RESUME -> {
                paused = false
                startOnce()
                return START_STICKY
            }
        }
        // ACTION_START: age-i foreground-e nilo (5 sec-er modhye startForeground lagbei)
        makeChannels()
        val note = listenNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTE_LISTEN, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTE_LISTEN, note)
        }
        paused = appVisible
        startOnce()
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        main.removeCallbacks(restart)
        stopRecognizer()
        super.onDestroy()
    }

    private fun startOnce() {
        if (!isRunning || paused) return
        stopRecognizer()
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(listener)
            rec = r
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            )
        } catch (e: Exception) {
            scheduleRestart(3000)
        }
    }

    private fun stopRecognizer() {
        try { rec?.cancel() } catch (e: Exception) { }
        try { rec?.destroy() } catch (e: Exception) { }
        rec = null
    }

    private fun scheduleRestart(ms: Long) {
        if (!isRunning || paused) return
        main.removeCallbacks(restart)
        main.postDelayed(restart, ms)
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResults(partialResults: Bundle?) { checkWake(partialResults) }

        override fun onResults(results: Bundle?) {
            checkWake(results)
            scheduleRestart(300)
        }

        override fun onError(error: Int) {
            // Busy hole ektu beshi somoy diye abar shuru
            scheduleRestart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 3000L else 700L)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun checkWake(b: Bundle?) {
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        if (list.none { heardWake(it) }) return
        val now = System.currentTimeMillis()
        if (now - lastWake < 6000L) return
        lastWake = now
        wake()
    }

    private fun wake() {
        stopRecognizer()
        main.removeCallbacks(restart)
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("wake", true)
        val pi = PendingIntent.getActivity(
            this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        // Notification: tap korle app khulbe, full-screen intent-o thakbe (permission thakle)
        val n = builder(CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("R.I.M.Y dakchhe")
            .setContentText("Ji, bolo...")
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .setPriority(Notification.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTE_ALERT, n)
        try { startActivity(open) } catch (e: Exception) { }
        // App khule MainActivity pause korbe; na khulle ektu pore abar shunbe
        scheduleRestart(4000L)
    }

    private fun builder(ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)

    private fun makeChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_LISTEN, "Hey Rimy shunchhe", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Rimy dakchhe", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun listenNotification(): Notification =
        builder(CH_LISTEN)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("R.I.M.Y")
            .setContentText("Hey Rimy bolle ami shonbo")
            .setPriority(Notification.PRIORITY_LOW)
            .setOngoing(true)
            .build()
}
