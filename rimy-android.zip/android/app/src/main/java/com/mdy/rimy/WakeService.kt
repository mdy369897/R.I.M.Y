package com.mdy.rimy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/**
 * "Hey Rimy" shonar background service (Vosk, sompurno offline).
 * App khola thakle pause thake. Background-e "rimy" shunle MainActivity khule dey.
 * Model prothombar ekbar internet theke download hoy, tarpor offline.
 */
class WakeService : Service() {

    companion object {
        const val ACTION_START = "com.mdy.rimy.WAKE_START"
        const val ACTION_STOP = "com.mdy.rimy.WAKE_STOP"
        const val ACTION_PAUSE = "com.mdy.rimy.WAKE_PAUSE"
        const val ACTION_RESUME = "com.mdy.rimy.WAKE_RESUME"

        private const val CH_LISTEN = "rimy_wake"
        private const val CH_ALERT = "rimy_alert"
        private const val NOTE_LISTEN = 7
        private const val NOTE_ALERT = 8

        private const val MODEL_NAME = "vosk-model-small-en-us-0.15"
        private const val MODEL_URL = "https://alphacephei.com/vosk/models/$MODEL_NAME.zip"
        private const val SAMPLE_RATE = 16000.0f

        // Shudhu ei shobdo-gulo-i recognize korbe, tai accuracy beshi ar CPU kom
        private const val GRAMMAR = "[\"hey\", \"rimy\", \"rimi\", \"remy\", \"[unk]\"]"
        private val WORDS = listOf("rimy", "rimi", "remy")

        @Volatile var isRunning = false
        @Volatile var appVisible = false

        fun heardWake(text: String): Boolean {
            val t = text.lowercase()
            return WORDS.any { t.contains(it) }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var model: Model? = null
    private var speech: SpeechService? = null
    private var paused = false
    private var lastWake = 0L
    private val restart = Runnable { startListening() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                isRunning = false
                main.removeCallbacks(restart)
                stopListening()
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> {
                paused = true
                stopListening()
                return START_STICKY
            }
            ACTION_RESUME -> {
                paused = false
                startListening()
                return START_STICKY
            }
        }
        // ACTION_START: foreground-e nilo (5 sec-er modhye startForeground lagbei)
        makeChannels()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTE_LISTEN, listenNotification("Model prostut hocche..."), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTE_LISTEN, listenNotification("Model prostut hocche..."))
        }
        paused = appVisible
        loadModelThenStart()
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        main.removeCallbacks(restart)
        stopListening()
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---------- Model: prothombar download, tarpor offline ----------

    private fun loadModelThenStart() {
        if (model != null) {
            updateNote("Hey Rimy shunchhe")
            startListening()
            return
        }
        worker.execute {
            try {
                val dir = File(filesDir, MODEL_NAME)
                if (!File(dir, "am").exists()) {
                    downloadModel(dir)
                }
                val m = Model(dir.absolutePath)
                model = m
                main.post {
                    updateNote("Hey Rimy shunchhe")
                    startListening()
                }
            } catch (e: Exception) {
                main.post { updateNote("Model pawa jay ni, internet check koro") }
            }
        }
    }

    // Zip download kore filesDir-e khule, tmp folder hoye final naam-e rakhe
    private fun downloadModel(target: File) {
        val zip = File(cacheDir, "$MODEL_NAME.zip")
        val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.inputStream.use { input ->
            FileOutputStream(zip).use { out -> input.copyTo(out) }
        }
        conn.disconnect()

        val tmp = File(filesDir, "$MODEL_NAME.tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val out = File(tmp, entry.name)
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        zip.delete()
        // Zip-er bhetore ekta folder thake: setar bhitore thaka content-ke target-e rakhi
        val inner = tmp.listFiles()?.firstOrNull { it.isDirectory } ?: tmp
        target.deleteRecursively()
        if (!inner.renameTo(target)) throw IllegalStateException("model rename hoy ni")
        tmp.deleteRecursively()
    }

    // ---------- Listening ----------

    private fun startListening() {
        if (!isRunning || paused) return
        val m = model ?: return
        stopListening()
        try {
            val rec = Recognizer(m, SAMPLE_RATE, GRAMMAR)
            val s = SpeechService(rec, SAMPLE_RATE)
            s.startListening(listener)
            speech = s
        } catch (e: Exception) {
            scheduleRestart(3000L)
        }
    }

    private fun stopListening() {
        try {
            speech?.stop()
            speech?.shutdown()
        } catch (e: Exception) {
        }
        speech = null
    }

    private fun scheduleRestart(ms: Long) {
        if (!isRunning || paused) return
        main.removeCallbacks(restart)
        main.postDelayed(restart, ms)
    }

    // Vosk callback background thread-e ase, tai sob main thread-e pathai
    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            val t = jsonField(hypothesis, "partial")
            main.post { checkWake(t) }
        }

        override fun onResult(hypothesis: String?) {
            val t = jsonField(hypothesis, "text")
            main.post { checkWake(t) }
        }

        override fun onFinalResult(hypothesis: String?) {
            val t = jsonField(hypothesis, "text")
            main.post { checkWake(t) }
        }

        override fun onError(exception: Exception?) {
            main.post { scheduleRestart(2000L) }
        }

        override fun onTimeout() {
            main.post { scheduleRestart(500L) }
        }
    }

    private fun jsonField(json: String?, key: String): String {
        return try {
            JSONObject(json ?: "").optString(key, "")
        } catch (e: Exception) {
            ""
        }
    }

    private fun checkWake(text: String) {
        if (text.isBlank() || !heardWake(text)) return
        val now = System.currentTimeMillis()
        if (now - lastWake < 6000L) return
        lastWake = now
        wake()
    }

    private fun wake() {
        stopListening()
        main.removeCallbacks(restart)
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("wake", true)
        val pi = PendingIntent.getActivity(
            this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = builder(CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("R.I.M.Y dakchhe")
            .setContentText("Ji, bolo...")
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .setPriority(Notification.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTE_ALERT, n)
        try { startActivity(open) } catch (e: Exception) { }
        // App khule MainActivity pause korbe; na khulle ektu pore abar shunbe
        scheduleRestart(4000L)
    }

    // ---------- Notification ----------

    private fun updateNote(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTE_LISTEN, listenNotification(text))
    }

    private fun builder(ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)

    private fun makeChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_LISTEN, "Hey Rimy shunchhe", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Rimy dakchhe", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun listenNotification(text: String): Notification =
        builder(CH_LISTEN)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("R.I.M.Y")
            .setContentText(text)
            .setPriority(Notification.PRIORITY_LOW)
            .setOngoing(true)
            .build()
}
